module.exports = {
  BOT_TOKEN: "7862666296:AAHurBCTMbZKWoy5BoytijE3hNHJMsTJfOI",
    allowedDevelopers: ['7320905929'], // ID
};